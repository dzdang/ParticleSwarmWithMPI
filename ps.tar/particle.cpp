#include "particle.h"
#include <vector>
#include <functional> 
#include <random> 

void particle::set_velocity(const std::vector<double> &input_velocity)
{
   velocity = input_velocity;
}

void particle::set_position(const std::vector<double> &input_position)
{
   position = input_position;
}

void particle::set_best_position(const std::vector<double> &input_position)
{
   best_position = input_position;
}

void particle::update_position()
{
   std::transform(position.begin(),position.end(),velocity.begin(),position.begin(),
      std::plus<double>());
}

void particle::update_velocity(const std::vector<double> &swarm_best)
{
   double c1 = 2; //make c1&x2 user-defined parametrs later
   double c2 = 3;
   std::mt19937 generator; 
   std::uniform_real_distribution<double> distribution(0.0,1.0);
   std::vector<double> term1;
   std::vector<double> term2;

   term1.resize(num_dim,0.0);
   term2.resize(num_dim,0.0);

   //we update velocity according to v(t+1) = v(t) + c1*rand()*(best_position - position)
   //+ (c2*rand()*(swarm_best - position))
   std::transform(best_position.begin(),best_position.end(),position.begin(),term1.begin(),
               std::minus<double>());

   std::transform(term1.begin(), term1.end(), term1.begin(),
               std::bind(std::multiplies<double>(), std::placeholders::_1, c1*distribution(generator)));

   std::transform(swarm_best.begin(),swarm_best.end(),position.begin(),term2.begin(),
               std::minus<double>());

   std::transform(term2.begin(), term2.end(), term2.begin(),
               std::bind(std::multiplies<double>(), std::placeholders::_1, c2*distribution(generator)));   

   //sum term1,term2,v(t)
   std::transform(velocity.begin(), velocity.end(), term1.begin(), 
               velocity.begin(),std::plus<double>());

   std::transform(velocity.begin(), velocity.end(), term2.begin(), 
               velocity.begin(),std::plus<double>());
}

std::vector<double> particle::get_best_position()
{
   return best_position;
}

std::vector<double> particle::get_position()
{
   return position;
}
