#include <iostream>
#include <vector>

int main(int argc, char const *argv[])
{
   std::vector<double> vec1(10);
   std::vector<double> vec2;
   // std::vector<double> vec2 = {3,5};
   // auto vec3 = vec1;


   // std::transform(vec1.begin(), vec1.end(), vec2.begin(), vec3.begin(),
      // std::plus<double>());
   vec2.resize(10);
   std::cout << vec1.size() << std::endl;
   std::cout << vec2.size() << std::endl;
   std::cout << vec1[0] << std::endl;
   std::cout << vec2[0] << std::endl;
   // return 0;
}