make clean
make all
./bin/pso
